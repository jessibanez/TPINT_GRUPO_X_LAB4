package entidad;

public enum EstadoPrestamo {
	
	PENDIENTE,
	APROBADO,
	RECHAZADO
	
}
